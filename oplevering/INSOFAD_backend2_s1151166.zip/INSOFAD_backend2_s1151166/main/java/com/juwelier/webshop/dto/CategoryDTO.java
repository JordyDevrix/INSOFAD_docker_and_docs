package com.juwelier.webshop.dto;

public class CategoryDTO {
    public String name;

    public CategoryDTO() {}
    public CategoryDTO(String name) {
        this.name = name;
    }
}
